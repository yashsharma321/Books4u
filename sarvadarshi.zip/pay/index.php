<?php
header("Location: https://www.instamojo.com/@sarvadarshi"); 
?>