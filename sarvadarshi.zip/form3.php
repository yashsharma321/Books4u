﻿<?php
error_reporting(0);
ini_set('display1_errors' , 0);
   if(isset($_FILES['image'])){
      $errors= array();
      $file_name = $_FILES['image']['name'];
      $file_size =$_FILES['image']['size'];
      $file_tmp =$_FILES['image']['tmp_name'];
      $file_type=$_FILES['image']['type'];
      $file_ext=strtolower(end(explode('.',$_FILES['image']['name'])));
      $expensions= array("jpeg","jpg","png","tif","tiff","gif");
      if(in_array($file_ext,$expensions)=== false){
         $errors[]="extension not allowed, please choose a JPEG or PNG file.";
      }
      if($file_size > 10097152){
         $errors[]='File size must be <= 10 MB';
      }
      if(empty($errors)==true){
         move_uploaded_file($file_tmp,"adb/".$file_name);
         echo "Success";
      }else{
         print_r($errors);
      }
   }
?>
<?PHP
$name       = @trim(stripslashes($_POST['fullname'])); 
$shop       = @trim(stripslashes($_POST['shop'])); 
$subject= "Sarvadarshi Advertisement";
$phone    = @trim(stripslashes($_POST['phone'])); 
$address    = @trim(stripslashes($_POST['address'])); 
$bidisha    = @trim(stripslashes($_POST['bidisha'])); 
$message    = @trim(stripslashes($_POST['message'])); 
$to         = 'yash.arkedia@gmail.com';
$from = "Sarvadarshi Magazine Siliguri <sarvadarshi1@gmail.com>"; 
$headers ="From:$from\n";
$headers.="MIME-Version: 1.0\n";
$headers.="Content-type: text/html; charset=iso 8859-1";
$message = "<html><body><p>A visitor to your site has sent the following message:</p> •••♥♥♥•••♥♥♥•••♥♥♥•••   •••♥♥♥•••♥♥♥•••♥♥♥•••   •••♥♥♥•••♥♥♥•••♥♥♥•••  <hr/><br/>
<h3>Shop: $shop<br/>Name: $name<br/>Subject: $subject<br/>Phone: $phone<br/>Address: $address<br/>Ad Size: $bidisha<br/>Message: $message<br/><br/><br/>Ad file: <br/><img src='http://www.sarvadarshi.in/adb/$file_name' alt='ad image'/></h3></html></body>";
  if(mail($to,$subject,$message,$headers))
{
echo '
<h1>Redirecting. Please Wait...</h1>
<script type="text/javascript">
           window.location = "https://imjo.in/xPpV7R"
      </script>';
exit();
}
else
{
    echo "Network Error! Please retry.";
}
 
?>
<BR/><BR/><BR/>
<button onclick="goBack()">Go Back</button>

<script>
function goBack() 
{
    window.history.back();
}
</script>