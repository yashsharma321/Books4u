<?php
 $smtp = Mail::factory('smtp', array(
          'host' => 'smtp.rediffmail.com',
          'port' => '587',
          'auth' => true,
          'username' => 'yashsharma2434@rediffmail.com',
          'password' => 'bidisha'
      ));
      ?>