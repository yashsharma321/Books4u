﻿<?PHP
$name       = @trim(stripslashes($_POST['fullname'])); 
$phone       = @trim(stripslashes($_POST['phone'])); 
$id       = @trim(stripslashes($_POST['id'])); 
$subject    = "Sarvadarshi Renew Subscription"; 
$message    = @trim(stripslashes($_POST['message'])); 
$to         = 'yash.arkedia@gmail.com';
$from = "Sarvadarshi Magazine Siliguri <sarvadarshi1@gmail.com>"; 
$headers ="From:$from\n";
$headers.="MIME-Version: 1.0\n";
$headers.="Content-type: text/html; charset=iso 8859-1";

$message = "<html><body><p>A visitor to your site has sent the following message:</p> •••♥♥♥•••♥♥♥•••♥♥♥•••   •••♥♥♥•••♥♥♥•••♥♥♥•••   •••♥♥♥•••♥♥♥•••♥♥♥•••  <hr/><br/>
<h3>Name: $name<br/>Phone: $phone<br/>ID: $id<br/>Subject: $subject<br/>Message: $message</h3></html></body>";

if(mail($to,$subject,$message,$headers))
{

header("Location: https://imjo.in/Z7EayG"); 
exit();
}
else
{
    echo "Network Error! Please retry.";
}
?>

<BR/><BR/><BR/>
<button onclick="goBack()">Go Back</button>

<script>
function goBack() {
    window.history.back();
}
</script>