<?php
require_once("Mail-1.4.1/Mail.php");
$from = 'yashsharma2434@rediffmail.com';
  $to = 'yashsharma2434@rediffmail.com';
  $subject = 'Hi!';
  $body = "<h1>Hi,\n\nHow are you?</h1>";
  $headers = array(
      'From' => $from,
      'To' => $to,
      'Subject' => $subject,
      'MIME-Version' => '1.0\n',
      'Content-type' => 'text/html; charset=iso 8859-1'
  );
   $smtp = Mail::factory('smtp', array(
          'host' => 'smtp.rediffmail.com',
          'port' => '587',
          'auth' => true,
          'username' => 'yashsharma2434@rediffmail.com',
          'password' => 'bidisha'
      ));
  $mail = $smtp->send($to, $headers, $body);
  if (PEAR::isError($mail)) {
      echo('<p>' . $mail->getMessage() . '</p>');
  } else {
      echo('<p>Message successfully sent!</p>');
  }
?>